# mobile-spin-game

<h3>Javascript api to using mobile spin game</h3>

<b><h4> Load game </h4></b>
@param {number} count - times of spin<br>
@param {string} name - user name<br>
<h5> function loadGame(count,name) </h5> 

<b><h4> Start to spin</h4></b>
@param {number} value - coupon value  <br>
@param {string} desc - Description of coupon when congratulation <br>
@param {string} url - coupon image <br>
<h5> function startSpin(value, desc, url)</h5>

<b><h4> On Button View all clicked at Congratulation screen </h4></b>
<h5>onViewAllClicked()</h5>

<b><h4> On Button Spin clicked at Spin screen </h4></b>
<h5>onSpinClicked()</h5> <br><br>

Example: <br>

For android:
```$xslt
class MainActivity : AppCompatActivity(0) {

    @SuppressLint("SetTextI18n", "SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        web.onViewAllClickedListener = {
            Toast.makeText(this, "View All Clicked", Toast.LENGTH_SHORT).show()
        }

        web.onSpinClickedListener = {
            web.startSpin(1, "Hello world", "https://adstech.vn/wp-content/uploads/2019/12/url-co-loi-ich-gi.jpg")
        }
    }
}

@SuppressLint("SetJavaScriptEnabled, JavascriptInterface, AddJavascriptInterface")
class GameWebView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : WebView(context, attrs, defStyleAttr) {
    private val mCallbacks = arrayListOf<() -> Unit>()
    private var mPageLoaded: Boolean = false
    var onViewAllClickedListener: () -> Unit = {}
    var onSpinClickedListener: () -> Unit = {}

    init {
        webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, loc: String) {
                mPageLoaded = true
                post {
                    mCallbacks.forEach { it() }
                    mCallbacks.clear()
                }
                loadGame(100)
            }
        }
        settings.javaScriptEnabled = true
        loadUrl("file:///android_asset/mobile-spin-game/index.html")
        addJavascriptInterface(WebAppInterface(), "Android")

    }

    private fun launch(function: () -> Unit) {
        if (mPageLoaded) post(function)
        else {
            mCallbacks.add(function)
        }
    }

    fun loadGame(count: Int) = launch {
        loadUrl("javascript:loadGame($count)")
    }

    fun startSpin(value: Int, desc: String, url: String) = launch {
        loadUrl("javascript:startSpin($value,\"$desc\",\"$url\")")
    }

    inner class WebAppInterface {
        @JavascriptInterface
        fun onViewAllClicked() {
            onViewAllClickedListener()
        }

        @JavascriptInterface
        fun onSpinClicked() {
            onSpinClickedListener()
        }
    }
}
```


