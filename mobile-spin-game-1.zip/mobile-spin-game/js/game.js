class Game {
    constructor() {
        this.spinScreen = new SpinScreen(".group-spin");
        this.congratsScreen = new CongratulationView(".congratulation");
        this.main = new View(".main");

        /** @type {Coupon}*/
        this.coupon = new EmptyCoupon();

        this.congratsScreen.hide();

        this.congratsScreen.btnCancel.onClick(() => {
            this.congratsScreen.hide(true);
            this.spinScreen.show();
        });

        this.spinScreen.vSpinner.onTransitionEnd(() => {
            setTimeout(() => {
                this.congratsScreen.show(this.coupon);
                this.spinScreen.hide();
            }, 600)
        });

        this.spinScreen.setOnSpinningListener((b) => {
            this.spinScreen.style["touch-action"] = b ? "none" : "initial"
        });

        this.spinScreen.adjustStatusBar();
        if (isIOSPlatform()) this.__disableScroll();
    }

    /**
     * @param {Coupon} coupon
     */
    startSpin(coupon) {
        this.coupon = coupon;
        this.spinScreen.startSpin(this.coupon);
    }

    __disableScroll() {
        this.main.style.overflowY = "hidden";
    }
}

class SpinScreen extends View {
    constructor(elementName) {
        super(elementName);

        this.btnSpin = new View(".btn-spin");
        this.vLight = new View(".light");
        this.vNoSpining = new View(".no-spining");
        this.vSpinner = new SpinnerView(".spinner");
        this.txtNumber = new View(".remain-number");
        this.txtName = new View(".thanks");
        this.imgLogo = new View(".logo");

        this.vLight.hide();

        this.setParams(0);

        this.vSpinner.onTransitionEnd(() => {
            setTimeout(() => {
                this.btnSpin.setEnablePointerEvent(true);
            }, 600)
        })
    }

    setParams(count, name) {
        this.remainCount = count;
        this.txtNumber.html(this.remainCount);
        this.txtName.html(name === undefined ? `Thanks for your<br>order!` : `Thanks for your<br>order ${name} !`);
        this.__updateChange()
    }

    /**
     * @param {Coupon} coupon
     */
    startSpin(coupon) {
        this.vLight.show(true);
        this.vNoSpining.hideAll(true);
        this.btnSpin.setEnablePointerEvent(false);
        let category = CATEGORIES.find((it) => it.value === coupon.value);
        if (category === undefined) category = CATEGORIES[0];
        this.vSpinner.start(category);
        this.__notifySpinningChange(true)
    }

    setOnSpinningListener(callback) {
        this.mSpinningListener = callback
    }

    show() {
        super.show(true);
        this.txtNumber.html(this.remainCount);
        this.vLight.hide(true);
        this.vNoSpining.showAll(true);
        this.vSpinner.reset();
        this.__updateChange();
        this.__notifySpinningChange(false)
    }

    hide() {
        super.hide(true);
        if (this.remainCount <= 0) return;
        this.remainCount -= 1
    }

    __notifySpinningChange(b) {
        if (this.mSpinningListener !== undefined) this.mSpinningListener(b)
    }

    __updateChange() {
        if (this.remainCount <= 0) this.btnSpin.hide();
        else this.btnSpin.show();
    }

    adjustStatusBar() {
        let translateTop = hasNotch();
        this.imgLogo.style.marginTop = translateTop ? "5vh" : "2vh";
        this.vLight.style.marginTop = translateTop ? "3vh" : "0";
    }
}

class SpinnerView extends View {
    constructor(elementName) {
        super(elementName);
        this.vWheel = new View('.wheel');
        this.deg = 0;
    }

    /**
     * @param {Models} category
     */
    start(category) {
        this.deg += category.randomRotation();
        this.vWheel.style.transitionDuration = "5s";
        this.vWheel.style.transform = `rotate(${this.deg}deg)`;
    }

    reset() {
        this.deg = 0;
        this.vWheel.style.transitionDuration = "0s";
        this.vWheel.style.transform = `rotate(${this.deg}deg)`;
    }
}

class CongratulationView extends View {
    constructor(elementName) {
        super(elementName);
        this.btnCancel = new View(".btn-cancel");
        this.btnViewAll = new View(".btn-view-all");
        this.txtDesc = new View(".desc");
        this.imgCoupon = new ImageView(".coupon-image")
    }

    /**
     * @param {Coupon} coupon
     */
    show(coupon) {
        this.txtDesc.html(`You received <br>${coupon.desc}`);
        this.imgCoupon.setImageUrl(coupon.url);
        super.show(true)
    }
}