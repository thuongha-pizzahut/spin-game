let game = new Game();
const debug = false;

/**
 * @param {number} count
 * @param {string} name
 */
function loadGame(count,name) {
    game.spinScreen.setParams(count, name)
}

/**
 * @param {number} value
 * @param {string} desc
 * @param {string} url
 */
function startSpin(value, desc, url) {
    game.startSpin(
        new Coupon(value, desc, url)
    )
}

game.congratsScreen.btnViewAll.onClick(() => {
    if(!debug) {
        if(isAndroidPlatform()) Android.onViewAllClicked();
        else {
            window.webkit.messageHandlers.onViewAllClicked.postMessage('onViewAllClicked');
        }
    }
});

game.spinScreen.btnSpin.onClick(() => {
    if(!debug) {
        if(isAndroidPlatform()) Android.onSpinClicked();
        else {
            window.webkit.messageHandlers.onSpinClicked.postMessage('onSpinClicked');
        }

    } else startSpin(0,"Hello world, congratulation","https://adstech.vn/wp-content/uploads/2019/12/url-co-loi-ich-gi.jpg")
});

if(debug) loadGame(2,"Anonymous");