class Models {
    constructor(name, value, index) {
        this.value = value;
        this.index = index
    }

    getRotation() {
        return (this.index * 1.0 / CATEGORIES.length) * 360
    }

    randomRotation() {
        let randomRange = Math.floor(Math.random() * 10 + 5);
        return 360 * randomRange + this.getRotation();
    }
}

class Coupon {
    constructor(value, desc, url) {
        this.value = value;
        this.url = url;
        this.desc = desc;
    }
}

class EmptyCoupon extends Coupon {
    constructor() {
        super(0, "Empty", "");
    }
}

const CATEGORIES = [
    new Models("Soup", 0, 0),
    new Models("Deli wings", 3, 1),
    new Models("Soup", 0, 2),
    new Models("Garlic", 1, 3),
    new Models("FAV", 2, 4),
    new Models("Garlic", 1, 5),
];